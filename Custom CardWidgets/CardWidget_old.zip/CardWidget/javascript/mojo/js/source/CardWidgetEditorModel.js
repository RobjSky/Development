(function () { 
    if (!mstrmojo.plugins.CardWidget) {
        mstrmojo.plugins.CardWidget = {};
    }

    mstrmojo.requiresCls(
        "mstrmojo.vi.models.editors.CustomVisEditorModel",
		"mstrmojo.plugins.CardWidget.CardWidget" , 
        "mstrmojo.array"
    );
    
	var $WT = mstrmojo.vi.models.editors.CustomVisEditorModel.WIDGET_TYPE ; 
	// pre Setted format value 


    mstrmojo.plugins.CardWidget.CardWidgetEditorModel = mstrmojo.declare(
        mstrmojo.vi.models.editors.CustomVisEditorModel,
        null,
        {
            scriptClass: "mstrmojo.plugins.CardWidget.CardWidgetEditorModel",
            cssClass: "CardWidgeteditormodel",
            getCustomProperty: function getCustomProperty(){


                var host = this.getHost(); 
                var indexViewType  = ""; 
                var allfont = "Arial" ; 
                var isIncrease =false  ; 
                var icontype = host.icontype ; 
                return [
                  {
                  	name : "Configuration" , 
					value :
					[		//var WidgetFontStyle = { labelfont : "labelfont" , valuefont : "valuefont" , chgfont  : "chgfont" , chgvaluefont  : "chgvaluefont" } ; 

					{
						style: $WT.EDITORGROUP,
						items: [{
							style: $WT.TWOCOLUMN,
							items: [{
								style: $WT.LABEL,
								name: "text",
								width: "35%",
								labelText: "Type:"
							}, {
								style: $WT.PULLDOWN,
								width: "65%",
								propertyName: "indextype",
								items: [
									{name : "Type1",value:"Type1" } ,
									{name : "Type2",value:"Type2" }, 
									{name : "Type3",value:"Type3" }, 
									{name : "Red",value:"Red" } ,
									{name : "Green",value:"Green" } ,
									{name : "Blue",value:"Blue" } ,
									{name : "Yellow",value:"Yellow" } ,
									{name : "Black",value:"Black" } ,
									{name : "White",value:"White" }  ,
									{name : "Small",value:"Small" } ,
									{name : "Big",value:"Big" } ,
									{name : "Korean",value:"Korean" } 
								]  , 
								config : {
								   suppressData: true , 
								   onPropertyChange: function (propertyName, newValue) {
								      if (newValue ) {
								      		indexViewType = newValue ; 
								      }
								       return {};
								    }
								    ,
								callback: function () 
									{
										host.setViewType(indexViewType) ;
									    host.refresh();
									}
								}

							}]
						} , 
						{
                                style: $WT.TWOCOLUMN,
                                items: [
                                    {
                                        style: $WT.LABEL,
                                        width: "30%",
                                        labelText: "Size:"
                                    },
                                    {
                                        style: $WT.BUTTONBAR,
                                        width: "70%",
                                        propertyName: "scales",
                                        items: [
                                            {
                                                labelText: "+",
                                                width : "50%",
                                                propertyName: "inc"
                                            },
                                            {
                                                labelText: "-",
                                                width : "50%",
                                                propertyName: "dec"
                                            }
                                        ],
                                        config: {
                                            suppressData: true,
                                            onPropertyChange: function (propertyName, newValue) {
                                                if (newValue.inc === "true") {
                                                 isIncrease = true ; 
                                                }
                                                return {};
                                            }
                                            ,
                                            callback: function () {
                                                host.increaseFont(isIncrease);
                                                host.refresh();
                                            } 
                                        },
                                        multiSelect: false
                                    }
                                ]
                            }
                            ]  
					} ,
					{
                        style: $WT.EDITORGROUP,
                        items: [ 
							{ // display mode 
								style: $WT.TWOCOLUMN,
								items: [{
									style: $WT.LABEL,
									name: "text",
									width: "35%",
									labelText: "Mode"
								}, {
									style: $WT.PULLDOWN,
									width: "65%",
									propertyName: "displaymode",
									items: [
										{name : "Matrix",value:"Matrix" }, 
										{name : "Row",value:"Row" } ,
										{name : "Column",value:"Column" } 
									]   
								}]
		                    } ,
		                    {
		                   		style: $WT.TWOCOLUMN,
									items: [{
										style: $WT.LABEL,
										name: "text",
										width: "40%",
										labelText: "Card Width"
									}, {
										style: $WT.TEXTBOX,
										width: "60%",
										propertyName: "cardwidth",
										disabled : this.getHost().getProperty('displaymode') === "Row"
									}]  	
		                    },
		                    {
		                   		style: $WT.TWOCOLUMN,
									items: [{
										style: $WT.LABEL,
										name: "text",
										width: "40%",
										labelText: "Card Height"
									}, {
										style: $WT.TEXTBOX,
										width: "60%",
										propertyName: "cardheight"
									}]  	
		                    } ,
		                    {
                            style: $WT.CHECKBOXANDLABEL,
                            propertyName: 'fitToCardToBox',
                            labelText: "Fit Card to Visualization "
		                    } , 
		                    {
                            style: $WT.CHECKBOXANDLABEL,
                            propertyName: 'fitToPage',
                            labelText: "Fit Text to Cards "
							} ,
							{ // display mode 
								style: $WT.TWOCOLUMN,
								items: [ 
								{
										style: $WT.LABEL,
										name: "text",
										width: "50%",
										labelText: "Metric Name"
								}, 
								{
										style: $WT.PULLDOWN,
										width: "50%",
										propertyName: "metricTitle",
										items: [
											{name : "All",value:"All" }, 
											{name : "Main",value:"HeadOnly" } ,
											{name : "Sub",value:"SubOnly" } ,
											{name : "None",value:"None" } 
										]   
								}]
							}
							,
							{ // display mode 
								style: $WT.TWOCOLUMN,
								items: [{
									style: $WT.LABEL,
									name: "text",
									width: "40%",
									labelText: "Metric Mode "  
								}, {
									style: $WT.PULLDOWN,
									width: "60%",
									propertyName: "metricDisplay"  ,
									disabled : this.getHost().zonesModel.getDropZoneObjectsByIndex(0).length >0 , 
									items: [
										{name : "Normal",value:"MNormal" }, 
										{name : "Fit",value:"MFit" }, 
										{name : "Cards",value:"MCard" }  
									]   
								}]
		                    }
							,
							{ // Main Metric Summary 
								style: $WT.TWOCOLUMN,
								items: [{
									style: $WT.LABEL,
									name: "text",
									width: "40%",
									labelText: "Trend Summary"  
								}, {
									style: $WT.PULLDOWN,
									width: "60%",
									propertyName: "metricSummary"  ,
									items: [
										{name : "Last",value:"Last" }, 
										{name : "Total",value:"Total" }
									]   
								}]
		                    }

                        ]
                    }
                    , 
					
                    {
                            style: $WT.EDITORGROUP,
                            items: [
                             {
	                            style: $WT.CHECKBOXANDLABEL,
	                            propertyName: 'isIcon',
	                            labelText: "Show Icon "
	                        },
                        	{
                                style: $WT.LABEL,
                                name: "text",
                                width: "100%",
                                labelText: "Icon Image Path" + "ex): http://yourserver/{@id}{@desc}.png"
                            }, {
                                style: $WT.TEXTBOX,
                                propertyName: "iconurl",
                                value: "",
                                disabled : this.getHost().getProperty('isIcon') === "false" , 
                                config: {
                                    suppressData: true
                                }
                            },
                            {
				                style: $WT.TWOCOLUMN,
								items: [{
					                   		style: $WT.TWOCOLUMN, 
					                   		width : "50%" ,
												items: [{
													style: $WT.LABEL,
													name: "text",
													width: "50%",
													labelText: "Size W:"
												}, {
													style: $WT.TEXTBOX,
													width: "50%",
													propertyName: "iconsize",
													  disabled : this.getHost().getProperty('isIcon') === "false" 
												}]  	
					                		},
						                	{
					                   		style: $WT.TWOCOLUMN,
					                   		width : "50%" ,
												items: [{
													style: $WT.LABEL,
													name: "text",
													width: "50%",
													labelText: "Size H:"
												}, {
													style: $WT.TEXTBOX,
													width: "50%",
													propertyName: "iconsizeH",
													  disabled : this.getHost().getProperty('isIcon') === "false" 
												}]  	
					                    	}]
		                	} ,
		                    { // Image Layout 
								style: $WT.TWOCOLUMN,
								items: [{
									style: $WT.LABEL,
									name: "text",
									width: "50%",
									labelText: "Icon Layout"
								}, {
									style: $WT.PULLDOWN,
									width: "50%",
									propertyName: "imagePosition",
									items: [
										{name : "Left",value:"Left" }, 
										{name : "Top",value:"Top" } ,
										{name : "Right",value:"Right" } ,
										{name : "Bottom",value:"Bottom" } 
									]   
								}]
		                    } 
							]
                    }
						
 					, 
					
					{ 
						style: $WT.EDITORGROUP,
						items: [
   							{
	                            style: $WT.CHECKBOXANDLABEL,
	                            propertyName: 'iscolorbyattribute',
	                            labelText: "Color by Category"
	                        } , 
							{
							style: $WT.TWOCOLUMN,
							items: [{
								style: $WT.LABEL,
								name: "text", 
								width: "35%",
								labelText: "Back:"
							}, {
								style: $WT.FILLGROUP,
								width: "65%",
								propertyName: "backColor",
								items: [{
									childName: "fillAlpha",
									disabled: true
								}]
							}]
						},
						{
							style: $WT.TWOCOLUMN,
							items: [{
								style: $WT.LABEL,
								name: "text",
								width: "35%",
								labelText: "Highlight:"
							}, {
								style: $WT.FILLGROUP,
								width: "65%",
								propertyName: "highColor",
								items: [{
									childName: "fillAlpha",
									disabled: true
								}]
							}]
						},
						{
							style: $WT.TWOCOLUMN,
							items: [{
								style: $WT.LABEL,
								name: "text",
								width: "35%",
								labelText: "Chart Color :"
							}, {
								style: $WT.FILLGROUP,
								width: "65%",
								propertyName: "chartColor",
								items: [{
									childName: "fillAlpha",
									disabled: false
								}]
							}]
						},
						{
	                            style: $WT.CHECKBOXANDLABEL,
	                            propertyName: 'dotChart',
	                            labelText: "Chart Point"
						 },
						 
						{
							style: $WT.CHECKBOXANDLABEL,
							propertyName: 'lineChart',
							labelText: "Chart Line"
					 	},
						 {
							style: $WT.CHECKBOXANDLABEL,
							propertyName: 'textChart',
							labelText: "Chart Text"
					 }

	                     ]
					},
					{
						style: $WT.EDITORGROUP,
						items: [
							{
	                            style: $WT.CHECKBOXANDLABEL,
	                            propertyName: 'animation',
	                            labelText: "Animation"
	                        }]
					}
/*					,
					{
                            style: $WT.EDITORGROUP,
                            items: [
                            	{ 	
                            	style: $WT.TWOCOLUMN,
								items: [
	                            	{
	                                style: $WT.LABEL,
	                                name: "text",
	                                width: "30%",
	                                labelText: "Icon:"
	                            	}, 
									{
									style: $WT.PULLDOWN,
									width: "70%",
									propertyName: "icontype",
									items: 	icontype 
									}]
								} , 
								{
									style: $WT.TWOCOLUMN,
									items: [{
										style: $WT.LABEL,
										name: "text",
										width: "30%",
										labelText: "Custom:"
									}, {
										style: $WT.TEXTBOX,
										width: "70%",
										propertyName: "customicon"
									}] 
								}
							
                            ]
                    }*/

					]
                   }
               ,  
               // Font Configuration .. 
                {

                 	name : "Fonts" , 
					value :
					[
                    {
                            style: $WT.EDITORGROUP,
                            items: [
                            {
								style: $WT.LABEL,
								name: "text",
								width: "100%",
								labelText: "Set All Fonts to"
							}, 
							{
								style: $WT.CHARACTERGROUP,
								propertyName: 'overallfont',
								items: [{
	                                        childName: 'fontSize',
	                                        disabled: true
	                                    },
	                                    {
	                                        childName: 'fontStyle',
	                                        disabled: true 
	                                    }
	                                    ] , 
	                                     config: {
	                                            suppressData: true,
	                                            onPropertyChange: function (propertyName, newValue) {
	                                                if (newValue) {
	                                                	allfont = newValue ; 
	                                                	// return { labelfont : newValue.fontFamily , valuefont : newValue.fontFamily } ; 
	                                                }
	                                                return {};
	                                            },
												callback: function () {
	                                                host.setAllFont(allfont);
	                                                host.refresh();
	                                            } 
	 
	                                     }
							}]
					} , 
					{ 
						style: $WT.EDITORGROUP,
						items: [{
							style: $WT.LABEL,
							name: "text",
							width: "100%",
							labelText: "Lable Font:"
						}, {
							style: $WT.CHARACTERGROUP,
							propertyName: 'labelfont',
							items: [{
								childName: 'fontSize'
							}]
						}]
					}
					, 
					{ 
						style: $WT.EDITORGROUP,
						items: [{
							style: $WT.LABEL,
							name: "text",
							width: "100%",
							labelText: "Metric Font:"
						}, {
							style: $WT.CHARACTERGROUP,
							propertyName: 'valuefont',
							items: [{
								childName: 'fontSize'
							}]
						}]
					}
					, 
					{ 
						style: $WT.EDITORGROUP,
						items: [{
							style: $WT.LABEL,
							name: "text",
							width: "100%",
							labelText: "Sub Metric Font:"
						}, {
							style: $WT.CHARACTERGROUP,
							propertyName: 'chgfont',
							items: [{
								childName: 'fontSize'
							}]
						}]
					}
/*					, 
					{ 
						style: $WT.EDITORGROUP,
						items: [{
							style: $WT.LABEL,
							name: "text",
							width: "100%",
							labelText: "Sub Metric 2 Font:"
						}, {
							style: $WT.CHARACTERGROUP,
							propertyName: 'chgvaluefont',
							items: [{
								childName: 'fontSize'
							}]
						}]
					} */
				
					]
               }                 			// End of Font  Configuration   
               ,
               {
               	    name : "Color By " , 
					value :					
					[
                    {
                            style: $WT.EDITORGROUP,
                            items: [
							      {
								        style: $WT.COLORBYGROUP
								  }
							]
						}
					]
               } // End of Color By 

               ]                  
}
})}());
//@ sourceURL=CardWidgetEditorModel.js
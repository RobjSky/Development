(function () { 
    if (!mstrmojo.plugins.CardWidget) {
        mstrmojo.plugins.CardWidget = {};
    }

    mstrmojo.requiresCls(
        "mstrmojo.CustomVisBase",
        "mstrmojo.models.template.DataInterface",
        "mstrmojo.vi.models.editors.CustomVisEditorModel"
    );

	var $intervalIndex = 0 ; 
	var $VISUTIL = mstrmojo.VisUtility ; 

	var $pluginName = "CardWidget"  ; 
	var isApp = window.webkit ? true  : false ;  
	var isMobile = window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.selectionDataJSONString ? true : false  ;
	var libPath = ((mstrApp.getPluginsRoot && mstrApp.getPluginsRoot()) || "../plugins/") + $pluginName  ; // ../plugins/CardWidget ..  
	var d3Path = isApp  ? "//d3js.org/d3.v4.min.js" : libPath + "/lib/d3.v4.min.js" ; 
	var METRIC_MODE = 1 , ATTRIBUTE_MODE =2 ;  
	var SINGLE_MODE = 1 , CHART_MODE =2 ; 
	var WidgetFontStyle = { labelfont : "labelfont" , valuefont : "valuefont" , chgfont  : "chgfont" , chgvaluefont  : "chgvaluefont" } ; 
	var WidgetFontStyleArr = [ WidgetFontStyle.labelfont , WidgetFontStyle.valuefont , WidgetFontStyle.chgfont ] ; 


	function isTrue(value) {
			return value === 'true' || value === true ? true : false;
	}; 

    mstrmojo.plugins.CardWidget.CardWidget = mstrmojo.declare
    (
        mstrmojo.CustomVisBase,
        null,
        {
            scriptClass: "mstrmojo.plugins.CardWidget.CardWidget",
            cssClass: "CardWidget",
            errorMessage: "Either there is not enough data to display the visualization or the visualization configuration is incomplete.",
            errorDetails: "This visualization requires one or more attributes and one metric.",
	        externalLibraries: isMobile ? [{url:"//d3js.org/d3.v4.min.js"}] : [{url:d3Path}],
            //externalLibraries: [{url:d3Path}],
            useRichTooltip: false,
            supportNEE: true,
            reuseDOMNode: false, 


			getFontStyle: function getFontStyle(styleName) {
				var fontStyle = {}; 
				var fontProps = this.getProperty(styleName) ;
				fontStyle.fontFamily = fontProps.fontFamily;
				fontStyle.fontColor = fontProps.fontColor ; 
				fontStyle.fontSize = fontProps.fontSize ; 
                fontStyle.fontStyle = isTrue(fontProps.fontItalic) ? 'italic' : 'normal';
                fontStyle.fontWeight = isTrue(fontProps.fontWeight) ? 'bold' : 'normal';
                fontStyle.textDecoration = "";
                if (isTrue(fontProps.fontUnderline)) {
                    fontStyle.textDecoration += ' underline';
                }

                if (isTrue(fontProps.fontLineThrough)) {
                    fontStyle.textDecoration += ' line-through';
                }

                if (fontStyle.textDecoration === "") {
                    fontStyle.textDecoration = "none";
                }                
				return fontStyle ; 
			},  
			increaseFont : function increaseFont(isIncrease) { 
				var increaseSize = isIncrease ? 2 : -2 ; 
				var tmpFont ={}; 
				for (i=0 ; i< WidgetFontStyleArr.length ; i++){
					var tmpFont = this.getProperty([ WidgetFontStyleArr[i]]) ; 
					var tmpSize = parseInt(tmpFont.fontSize)+ increaseSize  <8 ? 8 :parseInt(tmpFont.fontSize)+ increaseSize   ; 
					{tmpFont.fontSize =  tmpSize + "pt"; }
					this.setProperty(WidgetFontStyleArr[i] ,  tmpFont , { suppressData: true } )   ; 
				}
				var properties = this.getProperties() ; 
                properties["scales"] = {inc: 'false', dec: 'false'};
				return ; 
			}, 

			setAllFont : function setallfont (allfont){
				var tmpFont = {} ; 
				for (i=0 ; i< WidgetFontStyleArr.length ; i++){
					tmpFont = this.getProperty([ WidgetFontStyleArr[i]])  ; 
					Object.assign(tmpFont,allfont ) ; 
					this.setProperty(WidgetFontStyleArr[i], tmpFont , { suppressData: true }  )     ; 
				}

				return ; 
			}
			, 
			setViewType : function setViewType (newType) {
				var properties = this.getProperties();
				for (i=0 ; i< WidgetFontStyleArr.length ; i++){
					properties[ WidgetFontStyle[WidgetFontStyleArr[i]]] = this.indexViewType[newType][WidgetFontStyleArr[i]]  ;
				}
				this.setProperty("backColor", this.indexViewType[newType].backColor ,{suppressData:true }) ; 
				this.setProperty("highColor", this.indexViewType[newType].highColor ,{suppressData:true }) ; 
				this.setProperty("positiveColor", this.indexViewType[newType].positiveColor ,{suppressData:true }) ; 
				this.setProperty("negativeColor", this.indexViewType[newType].negativeColor ,{suppressData:true }) ; 
				return ; 	
			
			}, 
			getMetricName: function getMetricName() {
                var DIModel = new mstrmojo.models.template.DataInterface(this.model.data),
                    colHData = DIModel.getColumnHeaderData();

                return colHData && colHData[1] && colHData[1].n;
            },

			 ColorLuminance : function ColorLuminance(hex, lum) {

				// validate hex string
				hex = String(hex).replace(/[^0-9a-f]/gi, '');
				if (hex.length < 6) {
					hex = hex[0]+hex[0]+hex[1]+hex[1]+hex[2]+hex[2];
				}
				lum = lum || 0;

				// convert to decimal and change luminosity
				var rgb = "#", c, i;
				for (i = 0; i < 3; i++) {
					c = parseInt(hex.substr(i*2,2), 16);
					c = Math.round(Math.min(Math.max(0, c + (c * lum)), 255)).toString(16);
					rgb += ("00"+c).substr(c.length);
				}

				return rgb;
			} , 
			getChartColor  : function getChartColor (hex) {
				var r = parseInt (hex.substr(1,2),16); 
				var g = parseInt (hex.substr(3,2),16); 
				var b = parseInt (hex.substr(5,2),16); 
				var bright = (r * 299 + g * 587 + b * 114 ) / 1000 ; 
				return bright >= 128 ? "dark"  : "white" ; 
			},
            plot:function()
            {

            this.addUseAsFilterMenuItem();
            this.addThresholdMenuItem();  // Threshold 
            var DIModel =  new mstrmojo.models.template.DataInterface(this.model.data) ; 
            var DisplayMode  =  this.zonesModel && this.zonesModel.getDropZoneObjectsByIndex(0).length  ?   ATTRIBUTE_MODE : METRIC_MODE ;  
			var rawData ; 
			var data= [];  
		 
			var totalIndexName = isMobile  ? "DB" : "j1" ;
			var indexSplitString = isMobile  ? ":" : ";" ;
	
 			 // set property 
			 this.setDefaultPropertyValues (  

			 {	 indextype : "" ,  
 				 labelfont:		{ fontSize: '18pt', fontFamily: 'Arial',  fontWeight : 'false' ,  fontColor: '#202020' } ,
				 valuefont:  	{fontSize: '18pt',fontFamily: 'Arial',fontWeight : 'false' , fontColor: '#333333' }   ,
				 chgfont : 	 	{fontSize: '18pt',fontFamily: 'Arial',fontWeight : 'false' , fontColor: '#333333' }  ,
 			 	 backColor:  {fillColor : "#ffffff"  },   
				 highColor:   {fillColor: "#d6d6d6"} ,   
				 chartColor : {fillColor:"#005070" , fillAlpha : 100} , //#1F77B4 
				 dotChart : "true" ,
				 lineChart : "true",  
				 textChart : "true" , 
				 indexAlign : {left:true} , 
				 scale :  {inc: 'false', dec: 'false'} , 
				 iconurl :  "" ,
				 customicon : "" ,
				 cardwidth : 200 , 
				 cardheight : 150  ,  
				 metricTitle : "All" , 
				 metricSummary :"Last" , 
				 displaymode : "Matrix"  ,
				 isIcon : "false"  ,
				 fitToCardToBox : "true" ,
				 fitToPage : "true"  ,
				 metricDisplay : "isFit"  ,
				 iconsize : 45  ,
				 iconsizeH : 45 , 
				 animation : "true"   ,
				 iscolorbyattribute : "false"  ,
				 imagePosition : "Left" ,
 
			 });

		var metricCount = 0 ;  // number of Metric of this Widget 
		metricCount = DIModel.getColumnHeaderCount() ; 
	    if (metricCount == 0 ) {
	        throw 'ERROR';
	    }			

	    var me = this ; 

		var timeIndex = this.zonesModel.getDropZoneObjectsByIndex(2)[0] && this.zonesModel.getDropZoneObjectsByIndex(2)[0].id ; // Get Time Zone Attribute 
		var hasChart = timeIndex ? true : false ; 


 		// get properties  
		var backColor = this.getProperty("backColor").fillColor , 
			highColor = this.getProperty("highColor").fillColor  , 
			chartColor = this.getProperty("chartColor").fillColor  , 
			chartColorA = this.getProperty("chartColor").fillAlpha  ,
			dotChart =  isTrue(this.getProperty("dotChart")) ,    
			lineChart =  isTrue(this.getProperty("lineChart")) ,     
			colorbyattribute =  isTrue(this.getProperty("iscolorbyattribute")) ,
			textChart = isTrue(this.getProperty("textChart")) ;   

		var metricDisplayMode = this.getProperty("metricDisplay") ,
			metricTitle = this.getProperty("metricTitle") ,
			metricSummary = this.getProperty("metricSummary") ; 
		var isHeadMetricLabel = false , isSubMetricLabel  =false  ; 
		if (metricTitle=="All" || metricTitle == "HeadOnly") { 
			isHeadMetricLabel = true ; 
		}
		if (metricTitle=="All" || metricTitle == "SubOnly") { 
			isSubMetricLabel = true ; 
		}
		
		// Up , Down Symbol  and color 
		var propIsIcon = isTrue(this.getProperty("isIcon")) ; 
		var protFitToCardToBox = isTrue(this.getProperty("fitToCardToBox")) ; 
		var propFitToPage = isTrue(this.getProperty("fitToPage")) ; 
		var propIconUrl = this.getProperty("iconurl") ;
		var propMode =  this.getProperty("displaymode") ;
		var propItemWidth = parseInt(this.getProperty("cardwidth")) ;
		var propItemHeight = parseInt(this.getProperty("cardheight")) ;
		var propIconSize =  parseInt(this.getProperty("iconsize")) ; 
		var propIconSizeH =  parseInt(this.getProperty("iconsizeH")) ; 
		var propImagePosition = this.getProperty("imagePosition") 
		var propAnimation  =  isTrue(this.getProperty("animation"))    ;

		// get Font Style 
		var fontLabel = this.getFontStyle(WidgetFontStyle.labelfont);  
		var fontValue = this.getFontStyle(WidgetFontStyle.valuefont);  
		var fontChg = this.getFontStyle(WidgetFontStyle.chgfont);  

		var me = this; 

			var processChartData  = function (nodes,nodeName) {

	            	var processMetrics = function (m) { 
						var metrics = [] ; 
		            	// Metric Process.. 
		            	for ( i=0 ;  i<m.values.length ; i++  ) {
		            		metrics.push ({"name":m.values[i].name,"v" :m.values[i].v , "rv" : m.values[i].rv }) ;
		            		if( m.values[i].threshold && m.values[i].threshold.fillColor)  
		            			{ 
		            				metrics[i].tc  =  m.values[i].threshold.fillColor  ;
		            			}
		            	} 
		            	return metrics ; 
	            	} ; 
	            	var processCharts = function (ch) {
	            		var chD = [] ; 
	            		//console.table(ch);
	            		for (i=0;i<ch.length ; i++ ) {
	            			chD.push ({"x":ch[i].name , "metrics":ch[i].values}) ;
	            		}
	            		return chD ; 
	            	}
				
			        if ( nodes ) {
			            nodes.forEach(function(c) {
			            	// root Node... 
			            	var tmpData = {} ; 
								tmpData.name = c.name ; 

								if (isMobile) {
									tmpData.nodeId = c._eid.split(indexSplitString)[ c._eid.split(indexSplitString).length-1]; 
								}
								else {
									tmpData.nodeId = c._eid.split(indexSplitString)[0].slice(1); 	
								}

								tmpData.attributeSelector = c.attributeSelector  ;  // Selector 
								tmpData.colorInfo = c.colorInfo ; 
							var metricNode ; 
							
							// Process Metric Data 
			            	if ( c.children ) { // has Chart Data .. 
								//tmpData.metrics = processMetrics(c.children[c.children.length-1])  ;  // last item's data 								
								//tmpData.metrics = processMetrics(c.children[c.children.length-1])  ;  // total item's data 
								var metricNodeIndex =c.children.length-1; 
								var isTotal = false ; 
								
								if (metricSummary=="Total") {
									if (c.children[0]._eid.split(indexSplitString)[0]==totalIndexName) { // for total 
										metricNode = c.children[0] ; 
										metricNodeIndex = 0 ; 
										isTotal = true ; 
									}
									else if (c.children[c.children.length-1]._eid.split(indexSplitString)[0]==totalIndexName )
									{
										metricNode = c.children[c.children.length-1] ;
										isTotal = true ;
									}
									else {
										metricNode = c.children[c.children.length-1] ;
										isTotal = false ; 
									}
								}
								else {
									metricNode = c.children[c.children.length-1] ;
									isTotal = false ; 
								}

									tmpData.metrics = processMetrics(metricNode)  ;
									tmpData.colorInfo = c.children[metricNodeIndex].colorInfo ; // first children's color  

								// Process Chart 
								if(isTotal) {
									c.children.splice (metricNodeIndex,1)
								}
								tmpData.chartData = processCharts(c.children) ; 
								tmpData.chartX = c.children.length ; 

			            	} else {  // Single Data mode ... 
								tmpData.chartX = 0 ; 
								tmpData.metrics = processMetrics(c)  ; // Current Data 
			            	} 
			            	// Set Color 
							//tmpData.colorInfo = c.children[0].children[0].colorInfo || c.children[0].colorInfo || c.colorInfo  ;
			            	data.push (tmpData) ;
			            	//console.table(data); 
			            });
			        }

			    };




// process Data 
 		var metricChartData  = function metricChartData(metricRows , metricIndex, isTotal ,totalIndex ) {
 				var chD = [] ; 
					for (j=0;j<=metricRows ;  j++ ) { 						
						var chartMetric = [];
						if (isTotal && j==totalIndex ) {
							continue ; 							
						}
	            		chartMetric.push ({"name": DIModel.getColHeaders(0).getHeader(metricIndex).getName() ,
	            						"v" :  DIModel.getMetricValue(j,metricIndex).value.v , 
	            						"rv" : DIModel.getMetricValue(j,metricIndex).value.rv  }) ;
						chD.push ({"x":DIModel.getRowHeaders(j).getHeader(0).getName() , 
							"metrics":chartMetric}) ;
					}
				return chD;

 		} 
		if (DisplayMode == ATTRIBUTE_MODE ) { 
 					var colorAtt = {} ; 
 					if(colorbyattribute) { colorAtt =this.zonesModel && this.zonesModel.getColorByAttributes() }
					rawData =   this.dataInterface.getRawData(mstrmojo.models.template.DataInterface.ENUM_RAW_DATA_FORMAT.TREE,
											{ colorByInfo: colorAtt, 
											hasTitleName: true  , hasSelection:true , hasThreshold: true}); 
					processChartData (rawData.children, ""); 

		} 
		else { //Metric Mode  
			var metricRows = DIModel.getTotalRows() == 0 ? 0 : DIModel.getTotalRows()-1 ; 
			if (metricCount && metricDisplayMode != "MCard" ) { // consolidate Metrics into one 
				// First Metric for header .. 
				var tmpData = {} ; 
				tmpData.name = DIModel.getColHeaders(0).getHeader(0).getName()  ; 
				tmpData.nodeId = DIModel.getColHeaders(0).getHeader(0).getName() ;  
				tmpData.attributeSelector = "" ;   
				tmpData.colorInfo = "" ; 
				var metrics = [] ;
				var totalIndex =metricRows , isTotal = false ; 

				if (metricSummary=="Total") { 
					if (DIModel.getRowHeaders(0).getHeader(0).getElementId().split(indexSplitString)[0]==totalIndexName) {
						totalIndex = 0 ;
						isTotal = true ; 
					}
					else if (DIModel.getRowHeaders(metricRows).getHeader(0).getElementId().split(indexSplitString)[0]==totalIndexName) {
						totalIndex = metricRows ;
						isTotal = true ; 
					}
				} 


				// sub metrics 
				for ( i =0 ; i<metricCount ; i ++) {
				
	            		metrics.push ({"name": DIModel.getColHeaders(0).getHeader(i).getName() ,
	            						"v" :  DIModel.getMetricValue( totalIndex,i).value.v , 
	            						"rv" : DIModel.getMetricValue(totalIndex,i).value.v  }) ;
				}
				metrics[0].name = "";
				if (hasChart) {
					tmpData.chartX =metricRows ;
					 tmpData.chartData = metricChartData(metricRows,0,isTotal , totalIndex) ;
				}
	            tmpData.metrics =  metrics ; 
				data.push (tmpData) ;
			}
			else if (metricDisplayMode === "MCard" ) {
				// Each metric for each card .. 
				for ( i =0 ; i<metricCount ; i ++) {
					var tmpData = {} ; 
					tmpData.attributeSelector = "" ;   
					tmpData.colorInfo = "" ; 
					var metrics = [] ;
					var totalIndex =metricRows , isTotal = false ; 
						tmpData.name = DIModel.getColHeaders(0).getHeader(i).getName()  ; 
						tmpData.nodeId = DIModel.getColHeaders(0).getHeader(i).getName() ;  
						if (metricSummary=="Total") { 
							if (DIModel.getRowHeaders(0).getHeader(0).getElementId().split(indexSplitString)[0]==totalIndexName) {
								totalIndex = 0 ;
								isTotal = true ; 
							}
							else if (DIModel.getRowHeaders(metricRows).getHeader(0).getElementId().split(indexSplitString)[0]==totalIndexName) {
								totalIndex = metricRows ;
								isTotal = true ; 
							}
						} 
						metrics.push ({"name": "", //DIModel.getColHeaders(0).getHeader(i).getName() 
		            						"v" :  DIModel.getMetricValue( totalIndex,i).value.v , 
		            						"rv" : DIModel.getMetricValue(totalIndex,i).value.v  }) ;
						tmpData.metrics =  metrics ; 
						if (hasChart) {
							
							tmpData.chartData = metricChartData(metricRows,i,isTotal,totalIndex) ;
							tmpData.chartX =tmpData.chartData.length  ;
						}
						data.push (tmpData) ;
					}

	            

				
			}
	
		} 


		var divWidth = this.width , divHeight = this.height ; 
		var svgWidth = this.width -12 , svgHeight = this.height -12; 


		var itemCount = data.length  ; 
		var verticalMargin = 6 , horizontalMargin = 6;  
		var svgId = "svg" + this.k ; 
		// Display Mode 

		var itemWidth = propItemWidth ;  		
		var itemHeight = propItemHeight ; // Math.floor(itemWidth  * 0.7) ; 
		if (propMode==="Matrix" || propMode==="Column"  ) { 
				itemWidth = (propItemWidth)?propItemWidth :itemWidth ;
			} 
		else if (propMode==="Row") { 
			itemWidth = divWidth - horizontalMargin * 3 ; 
			itemHeight = propItemHeight ; 
			} // fit to the Width and set height from prop

		var chartW = 150 , chartH = 0 ; 
		var chartMargin = [10,10,10,10] ;

		if (DisplayMode === METRIC_MODE  )
		{
		//	propIsIcon = false ; 
			if ( metricDisplayMode === "MFit") {
			itemWidth = svgWidth ; 
			itemHeight = svgHeight ; 
			chartH = parseInt( svgHeight * 0.2)  ; 
			}
		}
		var iconSize = propIsIcon ?  propIconSize : 0 ; 
		var iconSizeH = propIsIcon ? propIconSizeH : 0 ; 
		var labelHeight = itemHeight  ; 
		var isImageStack = (propImagePosition === "Top" || propImagePosition  === "Bottom")   ? true : false ; 
		var iconSizeText = 45 ; 

		var cols = 1 , rows = 1; 
		while ( divWidth > ((itemWidth + verticalMargin ) * (cols+1)) && cols < itemCount) {
				cols+=1 ; 
		}
		if (protFitToCardToBox) {
			var cardMargin = Math.floor((divWidth - verticalMargin *2  - ((itemWidth + verticalMargin  ) * cols )) / cols)  ;  
			
			if ( itemWidth <  itemWidth + cardMargin ) 
				itemWidth += cardMargin    ; 

		} 

	// Calculate Label Height 
	// Card Mode : 20% , 50% , 30% 
	// Row Mode : 30% , 70% ,70% 
	// carLH : a = header , b = Main metric , c= sub metrics ... 
		var cardLH = {} , labelRHeight = labelHeight - (verticalMargin *2 ) -chartH , labelRWidth = itemWidth - (horizontalMargin * 2 ) ; 
		var SubMetricRows = Math.round((metricCount-1)/2) ;  
		if (DisplayMode === METRIC_MODE  &&  metricDisplayMode === "MCard" ) {SubMetricRows =0 ;}
		var fmtMetric = {width:0,height:0,  subWidth :0 , subHeight:0, basis :"auto" , grow :1 , subClassV:"metricValue" , subClassN : "metricName"} 
		 if (propMode !== "Row") { // column and matrix mode 
			var LabelEachHeight  = labelRHeight /  (SubMetricRows + 5) ;
			cardLH.a = LabelEachHeight +"px"; 
			var MetricHeight = (labelRHeight - LabelEachHeight ) / (SubMetricRows + 2); 
			
			cardLH.c = Math.round(MetricHeight) + "px" ; 
			// Metrics Width  
			if (propIsIcon && isImageStack)
			{
				cardLH.b = Math.round(MetricHeight ) +"px"; 
				fmtMetric.width = itemWidth  - verticalMargin *2 -2   ;  
			} 
			else 
			{
				cardLH.b = Math.round(MetricHeight*2 ) +"px"; 
				fmtMetric.width = itemWidth - iconSize - verticalMargin *2 -2   ;  	
			}
			
			fmtMetric.subWidth =labelRWidth/ 2; 
			// Chart  Setting for column 
			if (hasChart) 
					{ 
						chartW = itemWidth ; 
						if (DisplayMode === ATTRIBUTE_MODE ||  metricDisplayMode !== "MFit"  )
						  { chartH = Math.round(MetricHeight ) * 2;  itemHeight += chartH ; } ;
					} 
		}
		else  
			{	 
			cardLH.a = labelRHeight * 0.3 +"px"; cardLH.b=labelRHeight * 0.7+"px" ; cardLH.c = labelRHeight * 0.7 +"px";		
			fmtMetric.width = parseInt (itemWidth - iconSize - verticalMargin *2 -2 ) / (metricCount  + (hasChart ? 1 : 0 )) ; 
			
			if (hasChart) 
			{ 	chartH = parseFloat (cardLH.b) - horizontalMargin * 2; 
				if (chartW<=fmtMetric.width) 
					{chartW = fmtMetric.width ;}   
				else
					{fmtMetric.width -= (chartW - fmtMetric.width) / metricCount ;}
			}  
			fmtMetric.subWidth = fmtMetric.width ; 
		}


		for (i=0 ; i<itemCount ; i++) {
			var xPos =Math.round(i % cols) ;
			var yPos =Math.floor(i / cols) ;
			data[i].x = xPos  * (itemWidth + verticalMargin) + verticalMargin  ;
			data[i].y = yPos * (itemHeight + horizontalMargin) + horizontalMargin ;   
			if (propMode === "Column") {
				data[i].x = i * (itemWidth + verticalMargin) + verticalMargin  ;
				data[i].y = horizontalMargin ;   
			}
			data.cols = cols ; 
			data.rows = rows ; 
		}

 		
 		// Decide Scrolls 
 		svgHeight = data[itemCount-1].y + itemHeight + verticalMargin * data.rows *2 ; 
		//Container DIV
		d3.select(this.domNode).select('div').remove(); 
		var container  = d3.select(this.domNode).select("div");
		var contSvg = container.select(svgId) ;
		if (container.empty()) {
             container = d3.select (this.domNode).append("div") ; 
			 container.attr("id" , "custContainer"+this.k).style("width", divWidth +"px" ).style("height",divHeight +"px" )  ; 
			 container.attr("class", "Icont");
			 contSvg = container.append("div").attr("id",svgId).style("width",svgWidth +"px" ).style("height",(svgHeight -10	)+"px") ; 
			}		
		container.style("overflow","auto"); 

		var barItems = contSvg.selectAll("div").data(data).enter().append ("div")
			.style("height",itemHeight +"px").style("width",itemWidth+"px")
			.attr("class","card_item_rect") 
			.style("display","block")
			.style("text-align","center")
			.style("position","absolute")
			.style("top",verticalMargin +"px").style("left",horizontalMargin + "px"); 

var getTC = function getTC (tcData) {
	var rColor  = "" ;
	rColor =  me.getColorBy (tcData.colorInfo) ;
	// get first Threshold Info. 
	if (rColor =="" || rColor == null ) { 
		for ( i=0 ; i<tcData.metrics.length ; i ++ )
		{
			if (tcData.metrics[i].tc && tcData.metrics[i].tc !="" ){
				return tcData.metrics[i].tc ; 
			}
		}
	} 
	return rColor ;
} ; 

var selectedItem = "" ;
		barItems.on("click", function (d, i) {
						if (DisplayMode == ATTRIBUTE_MODE )  {
							barItems.style("background", function(d,i) { 
								//var color = me.getColorBy (d.colorInfo) ;  
								// Threshold Color 
								var color = getTC(d) ;

								if (color =="" || color == null ) { color =   backColor ; }  
								return color ; 
							}) ;
							if (selectedItem ==  d.attributeSelector.eid ) // click same item again .. 
							{
                                    if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.selectionDataJSONString) {  // mobile
                                        var d = {}
                                        d.messageType = "deselection";
                                        window.webkit.messageHandlers.selectionDataJSONString.postMessage(d);
                                    } else {
                                        me.clearSelections();
                                        me.endSelections();
                                    }
                                    selectedItem  = "";

							}
							else { 
									d3.select(this).style("background", highColor ) ; 
								    if(window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.selectionDataJSONString) { //for mobile
								      d.attributeSelector.messageType = "selection"; 
								      window.webkit.messageHandlers.selectionDataJSONString.postMessage(d.attributeSelector); 
								    } else {
								      me.applySelection(d.attributeSelector); //for web
								    }
								selectedItem = d.attributeSelector.eid ; 
									
							}

						}
	              	}) 
			;

	barItems.style("background" , function(d){ 
					//var color = me.getColorBy (d.colorInfo) ;  
					// Threshold Color 
					var color = getTC(d) ;
					if (color =="" || color == null ) 
						{ color = backColor ;}
					d.itemcolor = color ; 
					return color ;
				 })
			;
// Labels for each Card 
		
		var headLabels = barItems.append("div").text(function(d) {return d.name ; });
		headLabels.style("font-family",fontLabel.fontFamily)
		.style("font-size", fontLabel.fontSize).style("font-weight",fontLabel.fontWeight).style("color",fontLabel.fontColor).style("font-style",fontLabel.fontStyle)
		.style("white-space","nowrap");
		headLabels.style("text-align","left");
		headLabels.style("height",cardLH.a) ;


		// use Icon
		//barItems.node().appendChild(attIcon.node())
			var attIcon = barItems.append("div").attr("class","cardIcon").style("height",cardLH.b).style("width", (propImagePosition === "Top" || propImagePosition === "Bottom")  ? fmtMetric.width +"px" : "" )
			.style("float" , function() {return isImageStack ? "unset":"left" ; }) ; 
			var Icon ; 
			if (propIconUrl.trim() !== "") 
			{ 
					Icon = attIcon.append("div").append("img").style("border","0px").attr("src", function(d,i){
						 var iconUrl  =  propIconUrl.replace (/{@id}/gi,d.nodeId).replace(/{@desc}/gi,d.name) ; 
						 return iconUrl; })
					.attr("width",iconSize - verticalMargin + "px").attr("height",iconSizeH - horizontalMargin + "px")

					.on("error" , function (d,i){
						var a = d3.select(this);
						a.style("display","none");
						var p =d3.select( this.parentNode ); 
						p.append("div").attr("class","circle").style("width",iconSizeText +"px").style("height",iconSizeText +"px").append("span").text(d.name.substring(0,1));
						this.remove(); }) ;
			} 
			else {
				Icon  = attIcon.append("div").attr("class","circle").style("width",iconSizeText +"px").style("height",iconSizeText +"px").style("line-height" , iconSizeText  + "px").append("span").text(function(d){ 
					return d.name.substring(0,1) ;
				});
			}
			if (!propIsIcon) 
			{
				attIcon.style("height","0px").style("width","0px").style("display","none") ;  
				Icon.style("height","0px").style("width","0px"); 
 			}



		var metric1Labels = barItems.append("div");
		metric1Labels.attr("class","metricLabel") ;
		metric1Labels.attr("id","metric1Labels") ;
		metric1Labels.style("font-family",fontValue.fontFamily).style("font-size", fontValue.fontSize).style("font-weight",fontValue.fontWeight).style("color",fontValue.fontColor).style("font-style",fontValue.fontStyle);
		metric1Labels.style("width",fmtMetric.width +"px") ; 
		var metric1LabelsV = metric1Labels.append("div").attr("class","metricValue").text(function(d) {
				return d.metrics[0].v ; 
			}).attr("title" , function(d) {
				return d.metrics[0].v ; 
			});
		var metric1LabelsN 		;	
		if (isHeadMetricLabel)  {
			 metric1LabelsN =  metric1Labels.append("div").attr("class","metricName").text( function(d){ return d.metrics[0].name }) ;
		} 
		metric1Labels.style("height",cardLH.b) ;
		
	if (propImagePosition === "Right" || propImagePosition === "Bottom") 
	{
		attIcon.raise(); 
	}

		// Sub Metric 
		var subMetric = [] ; 
		if (DisplayMode === ATTRIBUTE_MODE || metricDisplayMode !== "MCard" ){
		for (si= 1 ; si<metricCount; si++) { 
			subMetric[si-1] = barItems.append("div").attr("class","metricSubLabel").attr("id","subMetric"+si);
			subMetric[si-1].style("font-family",fontChg.fontFamily)
				.style("font-size", fontChg.fontSize)
				.style("font-weight",fontChg.fontWeight).style("color",fontChg.fontColor).style("font-style",fontChg.fontStyle);
			subMetric[si-1].append("div").attr("class","metricValue").text(function(d) {return d.metrics[si].v; }).attr("title", function(d) {return d.metrics[si].v; }) ;
			subMetric[si-1].append("div").attr("class","metricName").text(function(d) {return d.metrics[si].name;}).style("display",function(){if (!isSubMetricLabel) return "none"}) ;

			subMetric[si-1].style("height",cardLH.c) ; 
			subMetric[si-1].style("width",fmtMetric.subWidth + "px") ; 
		}
		}

		// Fit to Div 
		var fitLabel  = function fitLabel (obj,pad,isFittoLongest,prevSize) {	
			var maxFt = 50 , minFt = 8 ;
			if (prevSize) { maxFt = prevSize ; }
			obj.style("font-size", maxFt + "pt") ;
			var iLongestNode = 0 ;
			if(isFittoLongest)  {
				for ( i = 0 ; i < obj.nodes().length ; i++) 
				{
					if ( obj.nodes()[iLongestNode].scrollWidth <= obj.nodes()[i].scrollWidth ) 
					{ 
						iLongestNode = i ;
					}
				}
			}

			var objH = parseFloat(obj.style("height")) + pad  ; 
			var objW = parseFloat(obj.style("width")) + pad  ;  
			while  ( obj.nodes()[iLongestNode].scrollHeight > objH || obj.nodes()[iLongestNode].scrollWidth > objW ) 
				{ 
					maxFt =parseInt(maxFt* 0.9)  ;
					obj.style("font-size",maxFt +"pt") ;
					if (maxFt <= minFt)  {break ; }
				} 
			return maxFt ;
		} ;
		var fitRowLabel = function fitRowLabel(obj,pad){
			var objW = parseFloat(obj.style("width")) + pad  ; 
			var curFt = parseInt(obj.style("font-size")) , minFt = 8 ;
			var reduceCnt = 0 ,  fitFont ={} ;
				while  ( obj.node().scrollWidth > objW ) 
					{  reduceCnt += 1 ; 
						//console.log(obj.node().scrollWidth + " : "  + objH);
						curFt =parseInt(curFt* 0.9)  ;
						obj.style("font-size",curFt +"pt") ;
						if (curFt <= minFt || reduceCnt > 10 )  { break ; }
					} 
				fitFont.curFt = curFt ; fitFont.reduceCnt = reduceCnt ; 
				return fitFont ; 
			}

		// Put it Margin... 
		var metric1Margin = parseInt(cardLH.b) / 8	  ; 
 		metric1LabelsV.style("padding-top",metric1Margin + "px") ;
	
		if (isHeadMetricLabel) {
			metric1LabelsN.style("padding-bottom",parseInt(cardLH.b) / 12 + "px") ;
		}
 		var iConMargin = (parseInt(cardLH.b)  - iconSize) /2   ; 
		attIcon.style("padding-top",metric1Margin + "px")  ;
 		if (propFitToPage) {
			var headerLabelFitSize = fitLabel (headLabels,2 ,false ) ;
			fitLabel(metric1Labels,2,true) ;  
			// fit for Row Label 
			var fitFont = fitRowLabel(metric1Labels , 2 ) ;  
			var prevSize = 50 ; 
		subMetric.forEach(function(el)
			{
				//fitLabel(el,2); 
				prevSize = fitLabel(el,2 ,true  , prevSize); 
				if (propMode === "Row") {
					// Put padding to sub metric 
					el.style("font-size",fitFont.curFt + "pt") ; 
				}
			}) ; 
		// adjust header font 
		if (fitFont!==undefined) {
			headLabels.style("font-size",parseInt( headLabels.style("font-size")) - fitFont.reduceCnt *2 + "pt") ;
		}
		} 
		subMetric.forEach(function(el)
		{
			el.selectAll("div").classed("metricElipsis",true) ;
			if (propMode === "Row") 
			{
				el.style("padding-top" , metric1Margin + "px" ) ; 
			}
		}) 

 		// Chart 

 		if (hasChart) { 

 			var ttDiv = barItems.append("div")	
		    .attr("class", "dotTip")
		    .attr("id",function(d,i){ return svgId +"tt"+i})				
		    .style("opacity", 0); 
		    var ttDivW = 78 , ttDivH = 46 ; 

			var chartRW = chartW -  chartMargin[1] -  chartMargin[3] , chartRH = chartH -  chartMargin[0] -  chartMargin[2] ;
			var chartG , chartD;
			if (propMode === "Row") {
			 	chartD = barItems.insert("div","#subMetric1");
			}
			else {
				chartD = barItems.append("div","#subMetric1");
			}
			chartD.attr("class","chartDiv").style("width",chartW).style("height",chartH); 
			chartG = chartD.append("svg").attr("width",chartW).attr("height",chartH).append("g").attr("width",chartW).attr("height",chartH);  
			var chartMinTextMargin = isApp? 5: 0 ; 
			chartG.each (function(el,ei){
				var sD = el.chartData.map(function(a){
					var tmp = {};
					tmp.lx=a.x;
					tmp.ly=a.metrics[0].rv ; 
					tmp.lyv=a.metrics[0].v ; 
					return tmp ; 
				}) ;
				g = d3.select(this) ; 
				var chartScaleX = d3.scaleBand().domain(sD.map(function(d){return d.lx})).rangeRound([chartMargin[3],chartRW]); 
				var chartScaleY = d3.scaleLinear()
								.domain( [d3.min(sD.map(function(d){return d.ly})) ,d3.max(sD.map(function(d){return d.ly}))])
								.rangeRound([chartRH,chartMargin[0]*2]);
				var chartLine = d3.line().x(function(d){return chartScaleX(d.lx)}).y(function(d){return chartScaleY(d.ly)}) 
				var chartArea = d3.area().x(function(d){return chartScaleX(d.lx)}).y0(chartScaleY(0)).y1(function(d){return chartScaleY(d.ly)}) 
				
				var tmpMin = sD[0] ,tmpMax = sD[0] ,tmpMinIndex = 0 , tmpMaxIndex = 0;  
				for (var i =1 ; i<sD.length ; i++) {
					if (tmpMin.ly>sD[i].ly){ tmpMin= sD[i] ;tmpMinIndex =i  }
					if (tmpMax.ly<sD[i].ly){ tmpMax= sD[i] ;tmpMaxIndex =i }
				}
				var chartRColor = chartColor ; 
				if(colorbyattribute &&  el.itemcolor && el.itemcolor!=="") 
				{
					if (me.getChartColor(el.itemcolor) == "dark") 
					{
							chartRColor = chartColor ;//"#0E3D5B" ;
					}
					else 
						{chartRColor = "#DFDFDF" ;}
				}

				g.append("path").datum(sD).attr("class","custom-vis-layout.CardWidget chartArea").style("fill" , me.ColorLuminance(chartRColor,0.25)).style("fill-opacity" , chartColorA / 100).attr("d",chartArea).style("display","none");
				g.append("path").datum(sD).attr("class","custom-vis-layout.CardWidget chartLine").attr("d",chartLine).style("stroke" , me.ColorLuminance(chartRColor,0.15)).style("display" , function(){return lineChart ? "block":"none";}) ;
				g.selectAll(".chartDot").data(sD).enter().append("circle").attr("class","chartDot").style("fill",me.ColorLuminance(chartRColor,0.1)).style("fill-opacity",chartColorA / 100)
						.attr("cx",function(d){ return chartScaleX(d.lx);} )
						.attr("cy",function(d){ return chartScaleY(d.ly);} )
						.attr("r", 4 )
						.style("fill-opacity",dotChart ? 1 : 0 )
						.on("mouseover",function(d){ 
							//var ttX = d3.event.layerX  , ttY =  d3.event.layerY  ; 
							var ttX = d3.event.offsetX  , ttY =  itemHeight - chartH + d3.event.offsetY  ; 
							if (ttX + ttDivW >= itemWidth ) {
								ttX  -= ttDivW ; 
							}
							if (ttY + ttDivH >= itemHeight ) {
								ttY  -= ttDivH ; 
							}
							tx = d3.select("#"+ svgId +"tt"+ei) ; 
							tx.transition().duration(200).style("opacity",0.9) ;
							tx.html(d.lx + "</br>" + d.lyv)
								.style("left", ttX + "px")		
	                			.style("top",  ttY + "px");		
						}).on("mouseout", function(d) {		
			            ttDiv.transition()		
		                .duration(500)		
		                .style("opacity", 0);	
		        });
				if (textChart){
				// Min
				g.append("text").attr("class","custom-vis-layout.CardWidget chartTextMin")
					.attr("x", chartScaleX(sD[tmpMinIndex].lx) ).attr("y",chartH-5-chartMinTextMargin)
				  .text(tmpMin.lyv).attr("alignment-baseline","baseline").attr("fill",chartRColor).attr("font-family",fontValue.fontFamily).attr("font-size","9pt") ; 
				  
				// Max 
				g.append("text").attr("class","custom-vis-layout.CardWidget chartTextMax").attr("x",chartScaleX(sD[tmpMaxIndex].lx))
				  .attr("y",0+chartMinTextMargin) //chartMargin[0]
				  .text(tmpMax.lyv).attr("alignment-baseline","hanging").attr("fill",chartRColor).attr("font-family",fontValue.fontFamily).attr("font-size","9pt");
				} 
 
	 		}) ;

		}
		var raisePDF = function raisePDF() {
			setTimeout ((me.raiseEvent({
				name: 'renderFinished',
				id: me.k
			})),500 )
		}
		// Transform and animation  if ( window.mstrApp&&window.mstrApp.isExporting ) 
		var animationDur = !window.mstrApp.isExporting && propAnimation ? 500  : 0 ; 
		
			barItems.transition().duration(animationDur)
				.style("top",function (d,i){ return  d.y + "px"})
				.style("left",function (d,i){ return  d.x + "px"}).on("end",raisePDF()) ;
		 // raise event for New Export Engine
		 me.raiseEvent({
			name: 'renderFinished',
			id: me.k
		});
		} // Plot  End 
		, 
		// Style Attributes 
		indexViewType : {	
			 Type1  : {
						labelfont 		:   {fontSize: '18pt', fontFamily: 'Arial',  fontWeight : 'false' ,  fontColor: '#202020' } , 
						valuefont  		: 	{fontSize: '18pt',fontFamily: 'Arial',fontWeight : 'false' , fontColor: '#333333' }  ,
						chgfont  	  	: 	{fontSize: '18pt',fontFamily: 'Arial',fontWeight : 'false' , fontColor: '#333333' }  ,
						backColor : {fillColor : "#fff"  },  highColor	: {fillColor: "#d6d6d6"} 
			        }  , 
			  Type2  : {
						labelfont 		: { fontSize: '18pt', fontFamily: 'Verdana',  fontWeight : 'false' ,  fontColor: '#87C458' } , 
						valuefont  		: 	{fontSize: '14pt',fontFamily: 'Verdana',fontWeight : 'false' , fontColor: '#343434' }  ,
						chgfont  	  	: 	{fontSize: '14pt',fontFamily: 'Verdana',fontWeight : 'false' , fontColor: '#343434' }  ,
						backColor : {fillColor : "#F7F7F7"  },  highColor	: {fillColor: "#B3CDEF"} 
			        }  , 
			 Type3  : { 
						labelfont  		: 	{fontSize: '18pt',fontFamily: 'Arial',fontWeight : 'false' , fontColor: '#333333' }  ,
						valuefont  		: 	{fontSize: '18pt',fontFamily: 'Verdana',fontWeight : 'false' , fontColor: '#333333' }  ,
						chgfont  	  	: 	{fontSize: '18pt',fontFamily: 'Arial',fontWeight : 'false' , fontColor: '#333333' }  ,
						backColor : {fillColor : "#D9D9D9"  } ,  highColor	: {fillColor: "#c0c0c0"} 
			        } , 
				Red   : {
						labelfont 		: {fontSize: '18pt',fontFamily: 'Helvetica',fontWeight : 'false' ,fontColor: '#ffffff'}	,
						valuefont  		: 	{fontSize: '14pt',fontFamily: 'Helvetica',fontWeight : 'true' , fontColor: '#ffffff' }  ,
						chgfont  	  	: 	{fontSize: '18pt',fontFamily: 'Helvetica',fontWeight : 'true' , fontColor: '#ffffff' }  ,
						backColor : {fillColor : "#E14C42"  } ,  highColor	: {fillColor: "#16B0FF"} 
			        } ,
			    Yellow   : {
						labelfont 		: {fontSize: '18pt',fontFamily: 'Arial',fontWeight : 'false' ,fontColor: '#333333'}	,
						valuefont  		: 	{fontSize: '14pt',fontFamily: 'Verdana',fontWeight : 'true' , fontColor: '#333333' }  ,
						chgfont  	  	: 	{fontSize: '18pt',fontFamily: 'Arial',fontWeight : 'false' , fontColor: '#333333' }  ,
						backColor : {fillColor : "#FDE47F"  },  highColor	: {fillColor: "#ff7a16"} 
			        } , 
			    Blue   : {
						labelfont 		: {fontSize: '18pt',fontFamily: 'Arial',fontWeight : 'false' ,fontColor: '#333333'}	,
						valuefont  		: 	{fontSize: '14pt',fontFamily: 'Verdana',fontWeight : 'true' , fontColor: '#333333' }  ,
						chgfont  	  	: 	{fontSize: '18pt',fontFamily: 'Arial',fontWeight : 'false' , fontColor: '#333333' }  ,
						backColor : {fillColor : "#81adf6"  },  highColor	: {fillColor: "#b2cdf9"} 
			        } , 			    
			        Black   : {
						labelfont 		: {fontSize: '18pt',fontFamily: 'Arial',fontWeight : 'false' ,fontColor: '#f3f3f3'}	,
						valuefont  		: 	{fontSize: '14pt',fontFamily: 'Verdana',fontWeight : 'true' , fontColor: '#f3f3f3' }  ,
						chgfont  	  	: 	{fontSize: '18pt',fontFamily: 'Arial',fontWeight : 'false' , fontColor: '#f3f3f3' }  ,
						backColor : {fillColor : "#000000"  } ,  highColor	: {fillColor: "#808080"} 
			        } , 
			    Green   : {
						labelfont 		: {fontSize: '18pt',fontFamily: 'Arial',fontWeight : 'false' ,fontColor: '#EBEBEB'}	,
						valuefont  		: 	{fontSize: '14pt',fontFamily: 'Verdana',fontWeight : 'true' , fontColor: '#EBEBEB' }  ,
						chgfont  	  	: 	{fontSize: '18pt',fontFamily: 'Arial',fontWeight : 'false' , fontColor: '#EBEBEB' }  ,
						backColor : {fillColor : "#70AD47"  },  highColor	: {fillColor: "#74CF57"} 
			        } , 
			    White   : {
						labelfont 		: {fontSize: '18pt',fontFamily: 'Arial',fontWeight : 'false' ,fontColor: '#202020'}	,
						valuefont  		: 	{fontSize: '14pt',fontFamily: 'Verdana',fontWeight : 'false' , fontColor: '#202020' }  ,
						chgfont  	  	: 	{fontSize: '18pt',fontFamily: 'Arial',fontWeight : 'false' , fontColor: '#202020' }  ,
						backColor : {fillColor : "#ffffff"  },  highColor	: {fillColor: "#e6e6e6"} 
			        } , 
			    Small   : {
						labelfont  		: 	{fontSize: '9pt',fontFamily: 'Trebuchet MS',fontWeight : 'true' , fontColor: '#333333' }  ,
						valuefont  		: 	{fontSize: '9pt',fontFamily: 'Trebuchet MS',fontWeight : 'false' , fontColor: '#333333' }  ,
						chgfont  	  	: 	{fontSize: '9pt',fontFamily: 'Trebuchet MS',fontWeight : 'false' , fontColor: '#333333' }  ,
						backColor : {fillColor : "#ffffff"  } ,  highColor	: {fillColor: "#969696"} 
			        } , 
			    Big   : {
						labelfont  		: 	{fontSize: '16pt',fontFamily: 'Trebuchet MS',fontWeight : 'true' , fontColor: '#333333' }  ,
						valuefont  		: 	{fontSize: '18pt',fontFamily: 'Trebuchet MS',fontWeight : 'false' , fontColor: '#333333' }  ,
						chgfont  	  	: 	{fontSize: '16pt',fontFamily: 'Trebuchet MS',fontWeight : 'false' , fontColor: '#333333' }  ,
						backColor : {fillColor : "#ffffff"  },  highColor	: {fillColor: "#969696"} 
			        } ,
			    Korean   : {
						labelfont  		: 	{fontSize: '18pt',fontFamily: 'Malgun Gothic',fontWeight : 'true' , fontColor: '#333333' }  ,
						valuefont  		: 	{fontSize: '14pt',fontFamily: 'Malgun Gothic',fontWeight : 'false' , fontColor: '#333333' }  ,
						chgfont  	  	: 	{fontSize: '9pt',fontFamily: 'Malgun Gothic',fontWeight : 'false' , fontColor: '#333333' }  ,
						backColor : {fillColor : "#ffffff"  },  highColor	: {fillColor: "#969696"} 
			        } 

			}  // end of indexView Type  
 


}
)


}());
//@ sourceURL=CardWidget.js
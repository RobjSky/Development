(function () { 
    if (!mstrmojo.plugins.CardWidget) {
        mstrmojo.plugins.CardWidget = {};
    }

    mstrmojo.requiresCls(
        "mstrmojo.vi.models.CustomVisDropZones",
        "mstrmojo.array"
    );

    mstrmojo.plugins.CardWidget.CardWidgetDropZones = mstrmojo.declare(
        mstrmojo.vi.models.CustomVisDropZones,
        null,
        {
            scriptClass: "mstrmojo.plugins.CardWidget.CardWidgetDropZones",
            cssClass: "CardWidgetdropzones",
            getCustomDropZones: function getCustomDropZones(){
  return [ 


                    {
                        name: 'Category',
                        title: mstrmojo.desc(13828, 'Drag attributes here'),
                        maxCapacity: 1,
                        allowObjectType: 1,
                        disabled: false ,
                        isColorBy: true
                    },
   
                    {
                        name: 'Metrics',
                        title: mstrmojo.desc(13827, 'Drag metrics here'),
                      /*  maxCapacity: 1, */ // No limit 
                        allowObjectType: 2,
                        disabled: false
                    },
                    {
                        name: 'Trend Attribute',
                        title: mstrmojo.desc(13828, 'Drag attributes here'),
                        maxCapacity: 1,
                        allowObjectType: 1

                    },
 /*                   {
                      name: mstrmojo.desc(900102, 'Color By'),
                      title: mstrmojo.desc(13828, 'Drag attributes here'),
                     maxCapacity: 1,
                      allowObjectType: 1,
                      isColorBy: false 
                    },           */    
 
 ];},
            shouldAllowObjectsInDropZone: function shouldAllowObjectsInDropZone(zone, dragObjects, idx, edge, context) {
 
 
 
 
 
 
 
 








},
            getActionsForObjectsDropped: function getActionsForObjectsDropped(zone, droppedObjects, idx, replaceObject, extras) {
 
 
 
 
 
 
 
 








},
            getActionsForObjectsRemoved: function getActionsForObjectsRemoved(zone, objects) { 
  
  
  
  
  
  
  
 








},
            getDropZoneContextMenuItems: function getDropZoneContextMenuItems(cfg, zone, object, el) {
 
 
 
 
 
 
 
 








}
})}());
//@ sourceURL=CardWidgetDropZones.js
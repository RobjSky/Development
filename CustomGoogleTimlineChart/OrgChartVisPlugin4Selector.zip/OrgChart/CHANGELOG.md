# Change Log
All notable changes to this project will be documented in this file.

## [0.0.1] - 2016-11-23
### Added
- OrgChart now supports exporting to PDF.


# Change Log
All notable changes to this project will be documented in this file.

## [0.0.1] - 2016-11-23
### Added
- GoogleSankey now supports exporting to PDF.

## [0.0.2] - 2018-01-02
### Added
- Visualization supports the filter selection on mobile devices.

## [0.0.3] - 2018-3-19
### Changed
- Updating style to load icons on RSD configuration page

## [0.0.4] - 2018-4-30
### Changed
- Fixing selection logic so you can select on both source & target elements. 

## [0.0.5] - 2018-6-28
### Added
- Added icon for the visualization
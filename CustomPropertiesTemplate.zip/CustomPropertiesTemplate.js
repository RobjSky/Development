(function (){
  // Define this code as a plugin in the mstrmojo object
  if (!mstrmojo.plugins.D3Funnel) {
    mstrmojo.plugins.D3Funnel = {};
  }
  // Import the necessary library
  mstrmojo.requiresCls(
    "mstrmojo.vi.models.editors.CustomVisEditorModel"
  );
  //variable that represent the enum of all the widget type
  var $WT = mstrmojo.vi.models.editors.CustomVisEditorModel.WIDGET_TYPE;
  /**
  * <p>Simple editor model for visualization using D3 library</p>
  >* <p>Define the properties displayed in property panel.</p>
  * @class mstrmojo.plugins.D3Funnel.D3FunnelEditorModel
  * @extends mstrmojo.vi.models.editors.CustomVisEditorModel
  */

  mstrmojo.plugins.D3Funnel.D3FunnelEditorModel = mstrmojo.declare(
    mstrmojo.vi.models.editors.CustomVisEditorModel,
    null,
    {
        // Define the JavaScript class that renders your visualization properties
        

      scriptClass: 'mstrmojo.plugins.D3Funnel.D3FunnelEditorModel',
      getCustomProperty: function getCustomProperty() {

        //Retrieve the viz created in the D3Funnel.js 
        var myViz = this.getHost();

        //Variable used to pass value from onPropertyChange to callback methods
        var labels;
        var labelsize;

        return [
            {
                name: 'My Custom Properties',
                value: [

                    //Create text box with a label in a two column format
                    {
                        style: $WT.EDITORGROUP,
                        items: [
                            //Create a label and a text box  
                            {       
                                style: $WT.TWOCOLUMN,
                                items: [
                                    {           
                                      style: $WT.LABEL,
                                      width: "40%",
                                      labelText: "Viz Name:"
                                    },{                
                                      style: $WT.TEXTBOX,
                                      width: "60%",
                                      propertyName: 'vizName'
                                    }
                                ]
                            }
                        ]
                    },

                    //Create Pull downs
                    {
                        style: $WT.EDITORGROUP,
                        items: [
                            //Create simple pull down
                           {
                                style: $WT.PULLDOWN,
                                propertyName: "pd",
                                items: [
                                    {
                                      name: "bold",
                                      value: "0"
                                    },
                                    {
                                      name: "italic",
                                      value: "1"
                                    }
                                ]
                            },
                            //Create pull down with labels
                            {
                                style: $WT.TWOCOLUMN,
                                items: [
                                    {
                                        style: $WT.LABEL,
                                        name: "text",
                                        width: "30%",
                                        labelText: "fontsize"
                                    },
                                    {
                                        style: $WT.PULLDOWN,
                                        propertyName: "textvalue",
                                        width: "70%",
                                        items: [
                                            {
                                              name: "10",
                                              value: "aaa"
                                            },
                                            {
                                              name: "20",
                                              value: "bbb"
                                            }
                                        ]
                                    }
                                ]
                            }
                        ]
                    },


                    //Create Button Bars
                    {
                        style: $WT.EDITORGROUP,
                        items: [
                           {
                                style: $WT.BUTTONBAR,
                                propertyName: "position",
                                items: [
                                    {
                                      labelText: "Top",
                                      propertyName: "t"
                                    },
                                    {
                                      labelText: "Middle",
                                      propertyName: "m"
                                    },
                                    {
                                      labelText: "Bottom",
                                      propertyName: "b"
                                    }
                                ],
                                multiSelect: false
                            }
                        ]
                    },

                    //Create Checklist
                    {
                        style: $WT.EDITORGROUP,
                        items: [
                            {
                                style: $WT.CHECKLIST,
                                propertyName: "cl",
                                items: [
                                  {
                                    labelText: "aaa",
                                    propertyName: "a"
                                  },
                                  {
                                    labelText: "bbb",
                                    propertyName: "b"
                                  },
                                  {
                                    labelText: "ccc",
                                    propertyName: "c"
                                  }
                                ],
                                orientation: "v",
                                multiSelect: false
                            }
                        ]
                    },

                    //Create Textbox
                    {
                        style: $WT.EDITORGROUP,
                        items: [
                            {
                              style: $WT.TEXTBOX,
                              propertyName: "valueTxt"
                            }
                            
                        ]
                    },

                    //Create Label
                    {
                        style: $WT.EDITORGROUP,
                        items: [
                            {
                              style: $WT.LABEL,
                              labelText: "Title"
                            }
                            
                        ]
                    },

                    //Create Checkbox
                    {
                        style: $WT.EDITORGROUP,
                        items: [
                            {
                              style: $WT.CHECKBOXANDLABEL,
                              propertyName: "cc",
                              labelText: "showLabel"
                            }
                            
                        ]
                    },


                    //Create ComboBox
                    {
                        style: $WT.EDITORGROUP,
                        items: [
                           {
                                style: $WT.COMBOBOX,
                                propertyName: "d11",
                                items: [
                                    {
                                      name: 1
                                    },
                                    {
                                      name: 2
                                    }
                                ]
                            }
                            
                        ]
                    },

                    //Create Stepper
                    {
                        style: $WT.EDITORGROUP,
                        items: [
                           {
                                style: $WT.STEPPER,
                                propertyName: "ff",
                                min: 0,
                                max: 10
                            }

                        ]
                    },

                    //Character Group 
                    {
                        style: $WT.EDITORGROUP,
                        items: [
                            {
                                style: $WT.CHARACTERGROUP,
                                propertyName: "labelFont"
                            }
                            
                        ]
                    },

                    //FillGroup and LineGroup
                    {
                        style: $WT.EDITORGROUP,
                        items: [
                            {
                                style: $WT.FILLGROUP,
                                propertyName: "labelFillColor"
                            },

                            {
                                style: $WT.LINEGROUP,
                                propertyName: "labelBorder"
                            }
                            
                        ]
                    }
                    
                ]
            }
        ];
      }    
    }
  );
}());
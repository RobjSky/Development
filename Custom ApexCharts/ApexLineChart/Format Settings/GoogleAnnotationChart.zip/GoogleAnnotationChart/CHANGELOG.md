# Change Log
All notable changes to this project will be documented in this file.

## [0.0.1] - 2016-11-23
### Added
- GoogleAnnotationChart now supports exporting to PDF.

## [0.0.2] - 2018-03-02
### Added
- Update icon to use svg


## [0.0.3] - 2018-05-01
### Fixed
- Fixing date logic as js dates are base 0, also resolving issues related to selectors invoking selection twice. 